const mysqlConfig = {
  host: "localhost",
  database: "tvcvlnrr_database",
  user: "tvcvlnrr_admin",
  password: "sUkNH1@.n2Gu",

  //------------
  // host: "localhost",
  // user: "root",
  // database: "tvc",
  // password: "",
};

export default mysqlConfig;

const mysqlConfig = {
  // host: "localhost",
  // database: "tvcvlnrr_wp344",
  // user: "tvcvlnrr_wp344",
  // password: "(g@(X4S2(]cp5zP5",
  //------------
  host: "localhost",
  user: "root",
  database: "tvc",
  password: "password",
  port: 3306,
};

export default mysqlConfig;

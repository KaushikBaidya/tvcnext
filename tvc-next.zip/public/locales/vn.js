export const vn = {
  home: "TRANG CHỦ",
  about: "VỀ CHÚNG TÔI",
  products: "MỸ PHẨM",
  contact: "LIÊN HỆ",
  //---------hero section-------------
  welcome: "Chào mừng bạn đến với",
  tvc: "TVC VIỆT NAM",
  subtitle:
    "Viên nén gỗ có thể được sử dụng thay thế cho than, củi, dầu và khí đốt trong các nhà máy sưởi, nấu ăn, lò hơi và nhà máy điện.",
  a_subtitle:
    "Một cách sử dụng thay thế cho viên nén gỗ là giường động vật như trong chuồng ngựa, và tất cả các viên nén của chúng tôi đều tuyệt vời cho việc này ..",
  learn_btn: "Tìm hiểu thêm",
  //----------about section--------------
  title_about: "ĐÔI LỜI VỀ",
  title_us: "CHÚNG TÔI",
};

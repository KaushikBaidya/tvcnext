export const en = {
  home: "HOME",
  about: "ABOUT US",
  products: "PRODUCTS",
  contact: "CONTACT US",
  //---------hero section-------------
  welcome: "Welcome to",
  tvc: "TVC VIETNAM",
  subtitle:
    "Wood pellets can be used instead of charcoal, firewood, oil and gas in heating, cooking, boiler and power plants.",
  a_subtitle:
    "An alternative use for wood pellets is animal bedding such as in horse stalls, and all of our pellets are excellent for this..",
  learn_btn: "Learn More",
  //----------about section--------------
  title_about: "About",
  title_us: "Us",
};

import React from "react";

const Dashboard = () => {
  return (
    <div className="my-5 mx-2">
      <h1>This is Dashboard</h1>
    </div>
  );
};

export default Dashboard;

"use strict";
exports.id = 1691;
exports.ids = [1691];
exports.modules = {

/***/ 6328:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
exports.Z = _interopRequireDefault;
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}


/***/ }),

/***/ 1691:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _interopRequireDefault = (__webpack_require__(6328)/* ["default"] */ .Z);
const _db = /*#__PURE__*/ _interopRequireDefault(__webpack_require__(6457));
const mysql = __webpack_require__(2418);
const getCategories = async ()=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute("SELECT * FROM `categories` ");
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getCategorySelect = async ()=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute("SELECT categoryId as listId, category as listName FROM `categories` ");
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getCategoryById = async (categoryId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows] = await connection.execute(`SELECT * FROM categories WHERE categoryId = ${categoryId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const createCategory = async (category)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`INSERT INTO categories ( category ) VALUES ("${category}");`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const updateCategory = async (categoryId, updatedCategory)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`UPDATE categories SET category = "${updatedCategory}" WHERE categoryId = ${categoryId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const deleteCategoryId = async (categoryId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`DELETE FROM categories WHERE categoryId = ${categoryId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const categories = {
    getCategories,
    getCategoryById,
    createCategory,
    updateCategory,
    getCategorySelect,
    deleteCategoryId
};
module.exports = categories;


/***/ }),

/***/ 6457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "tvcvlnrr_database",
    user: "tvcvlnrr_admin",
    password: "sUkNH1@.n2Gu"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ })

};
;
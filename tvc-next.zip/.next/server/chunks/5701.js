"use strict";
exports.id = 5701;
exports.ids = [5701];
exports.modules = {

/***/ 9005:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "en": () => (/* binding */ en)
/* harmony export */ });
const en = {
    home: "HOME",
    about: "ABOUT US",
    products: "PRODUCTS",
    contact: "CONTACT US",
    //---------hero section-------------
    welcome: "Welcome to",
    tvc: "TVC VIETNAM",
    subtitle: "Wood pellets can be used instead of charcoal, firewood, oil and gas in heating, cooking, boiler and power plants.",
    a_subtitle: "An alternative use for wood pellets is animal bedding such as in horse stalls, and all of our pellets are excellent for this..",
    learn_btn: "Learn More",
    //----------about section--------------
    title_about: "About",
    title_us: "Us"
};


/***/ }),

/***/ 9371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "vn": () => (/* binding */ vn)
/* harmony export */ });
const vn = {
    home: "TRANG CHỦ",
    about: "VỀ CH\xdaNG T\xd4I",
    products: "MỸ PHẨM",
    contact: "LI\xcaN HỆ",
    //---------hero section-------------
    welcome: "Ch\xe0o mừng bạn đến với",
    tvc: "TVC VIỆT NAM",
    subtitle: "Vi\xean n\xe9n gỗ c\xf3 thể được sử dụng thay thế cho than, củi, dầu v\xe0 kh\xed đốt trong c\xe1c nh\xe0 m\xe1y sưởi, nấu ăn, l\xf2 hơi v\xe0 nh\xe0 m\xe1y điện.",
    a_subtitle: "Một c\xe1ch sử dụng thay thế cho vi\xean n\xe9n gỗ l\xe0 giường động vật như trong chuồng ngựa, v\xe0 tất cả c\xe1c vi\xean n\xe9n của ch\xfang t\xf4i đều tuyệt vời cho việc n\xe0y ..",
    learn_btn: "T\xecm hiểu th\xeam",
    //----------about section--------------
    title_about: "Đ\xd4I LỜI VỀ",
    title_us: "CH\xdaNG T\xd4I"
};


/***/ })

};
;
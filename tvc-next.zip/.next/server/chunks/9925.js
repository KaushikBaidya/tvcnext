"use strict";
exports.id = 9925;
exports.ids = [9925];
exports.modules = {

/***/ 6328:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
exports.Z = _interopRequireDefault;
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}


/***/ }),

/***/ 9925:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _interopRequireDefault = (__webpack_require__(6328)/* ["default"] */ .Z);
const _db = /*#__PURE__*/ _interopRequireDefault(__webpack_require__(6457));
const mysql = __webpack_require__(2418);
const getFooter = async ()=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute("SELECT * FROM `footer` ");
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getFooterById = async (footerId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows] = await connection.execute(`SELECT * FROM footer WHERE footerId = ${footerId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const createFooter = async (name, address, address2, email, email2, number, number2, facebook, whatsapp, twitter, youtube, zalo, wechat, viber)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`INSERT INTO footer ( name, address, address2, email, email2, number, number2, facebook, whatsapp, twitter, youtube, zalo, wechat, viber) VALUES ('${name}', '${address}', '${address2}', '${email}','${email2}', '${number}', '${number2}', '${facebook}', '${whatsapp}', '${twitter}', '${youtube}', '${zalo}', '${wechat}', '${viber}' );`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const updateFooter = async (footerId, UpdatedName, updatedAddress, updatedAddress2, updatedEmail, updatedEmail2, updatedNumber, updatedNumber2, updatedFacebook, updatedWhatsapp, updatedTwitter, updatedYoutube, updatedZalo, updatedWechat, updatedViber)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`UPDATE footer SET name = '${UpdatedName}', address = '${updatedAddress}', address2 = '${updatedAddress2}', email = '${updatedEmail}',email2 = '${updatedEmail2}', number ='${updatedNumber}', number2 ='${updatedNumber2}', facebook = '${updatedFacebook}', youtube = '${updatedYoutube}', wechat = '${updatedWechat}', zalo ='${updatedZalo}', viber = '${updatedViber}', whatsapp = '${updatedWhatsapp}', twitter = '${updatedTwitter}' WHERE footerId = '${footerId}'`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
// const deleteAddressId = async (addressId) => {
//   try {
//     const connection = await mysql.createConnection(mysqlConfig);
//     const [rows, fields] = await connection.execute(
//       `DELETE FROM address WHERE addressId = ${addressId}`
//     );
//     return rows;
//   } catch (e) {
//     console.error(e);
//   }
// };
const footer = {
    getFooter,
    createFooter,
    updateFooter,
    getFooterById
};
module.exports = footer;


/***/ }),

/***/ 6457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    host: "localhost",
    database: "tvcvlnrr_database",
    user: "tvcvlnrr_admin",
    password: "sUkNH1@.n2Gu"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ })

};
;
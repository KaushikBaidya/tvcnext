"use strict";
exports.id = 303;
exports.ids = [303];
exports.modules = {

/***/ 303:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1908);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3096);
/* harmony import */ var _common_button_SaveButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6139);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const schema = yup__WEBPACK_IMPORTED_MODULE_3__.object({
    footerId: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    name: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required.").max(500),
    address: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required.").max(500),
    address2: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    email: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required.").max(500),
    email2: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    number: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("Required.").max(500),
    number2: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    facebook: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    whatsapp: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    twitter: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    youtube: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    zalo: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    wechat: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50),
    viber: yup__WEBPACK_IMPORTED_MODULE_3__.string().max(50)
});
const FooterForm = ({ defaultValues , path , mutateAsync , action , btnText , returnPath ,  })=>{
    const { 0: submitting , 1: setSubmitting  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { register , handleSubmit , reset , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
        defaultValues: defaultValues,
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__.yupResolver)(schema)
    });
    const { name , address , address2 , email , email2 , number , number2 , facebook , whatsapp , twitter , youtube , zalo , wechat , viber ,  } = errors;
    const onSubmit = async (formData)=>{
        setSubmitting(true);
        let data = {
            footerId: formData.footerId,
            name: formData.name,
            address: formData.address,
            address2: formData.address2,
            email: formData.email,
            email2: formData.email2,
            number: formData.number,
            number2: formData.number2,
            facebook: formData.facebook,
            whatsapp: formData.whatsapp,
            twitter: formData.twitter,
            youtube: formData.youtube,
            zalo: formData.zalo,
            wechat: formData.wechat,
            viber: formData.viber
        };
        try {
            const { status  } = await mutateAsync({
                path: path,
                formData: data
            });
            if (status === 201) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Saved successfully!");
                reset();
            }
            if (status === 204) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Update successful!");
                router.push(returnPath);
            }
        } catch (error) {
            if (error.response) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Response : " + error.response.data);
            } else if (error.request) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Request : " + error.message);
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Error :", error.message);
            }
        } finally{
            setSubmitting(false);
            action();
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "hidden",
                ...register("footerId")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "form-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "name",
                        label: "Company Name",
                        type: "text",
                        register: register,
                        errorMessage: name?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "address",
                        label: "Main Address",
                        type: "text",
                        register: register,
                        errorMessage: address?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "address2",
                        label: "Alternative Address",
                        type: "text",
                        register: register,
                        errorMessage: address2?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "email",
                        label: "Main Email",
                        type: "text",
                        register: register,
                        errorMessage: email?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "email2",
                        label: "Alternative Email",
                        type: "text",
                        register: register,
                        errorMessage: email2?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "number",
                        label: "Main Number",
                        type: "text",
                        register: register,
                        errorMessage: number?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "number2",
                        label: "Alternative number",
                        type: "text",
                        register: register,
                        errorMessage: number2?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "facebook",
                        label: "Facebook Link",
                        type: "text",
                        register: register,
                        errorMessage: facebook?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "whatsapp",
                        label: "Whatsapp Link",
                        type: "text",
                        register: register,
                        errorMessage: whatsapp?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "twitter",
                        label: "Twitter Link",
                        type: "text",
                        register: register,
                        errorMessage: twitter?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "youtube",
                        label: "Youtube Link",
                        type: "text",
                        register: register,
                        errorMessage: youtube?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "zalo",
                        label: "Zalo Link",
                        type: "text",
                        register: register,
                        errorMessage: zalo?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "wechat",
                        label: "WeChat Link",
                        type: "text",
                        register: register,
                        errorMessage: wechat?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        name: "viber",
                        label: "Viber Link",
                        type: "text",
                        register: register,
                        errorMessage: viber?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_button_SaveButton__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        btnText: btnText,
                        disabled: submitting
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6139:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const SaveButton = ({ btnText , disabled , isRow =true  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: isRow ? "form-row w-full" : "md:mt-6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            type: "submit",
            className: "save-btn",
            disabled: disabled,
            children: btnText
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SaveButton);


/***/ })

};
;
"use strict";
(() => {
var exports = {};
exports.id = 669;
exports.ids = [669];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 8689:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_productController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4178);
/* harmony import */ var _controller_productController__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_controller_productController__WEBPACK_IMPORTED_MODULE_0__);

async function handler(req, res) {
    const productId = req.query.productId;
    const method = req.method;
    let result;
    switch(method){
        case "GET":
            result = await (0,_controller_productController__WEBPACK_IMPORTED_MODULE_0__.getProductById)(productId);
            res.json(result);
            break;
        case "DELETE":
            result = await (0,_controller_productController__WEBPACK_IMPORTED_MODULE_0__.deleteProductById)(productId);
            res.json({
                ...result,
                message: `product with productId: ${productId} deleted`
            });
            break;
        case "POST":
            const name = req.body.name;
            const description = req.body.description;
            const name_vn = req.body.name_vn;
            const description_vn = req.body.description_vn;
            const image = req.body.image;
            const category = req.body.category;
            result = await (0,_controller_productController__WEBPACK_IMPORTED_MODULE_0__.createProduct)(name, description, name_vn, description_vn, image, category);
            res.status(201).json({
                ...result,
                message: `product with name: ${name} created`
            });
            break;
        case "PUT":
            const updateName = req.body.name;
            const updateNameVn = req.body.name_vn;
            const updateDescription = req.body.description;
            const updateDescriptionVn = req.body.description_vn;
            const updateImage = req.body.image;
            const updateCategory = req.body.category;
            result = await (0,_controller_productController__WEBPACK_IMPORTED_MODULE_0__.updateProduct)(productId, updateName, updateNameVn, updateDescription, updateDescriptionVn, updateImage, updateCategory);
            res;
            res.status(204).end("end");
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4178], () => (__webpack_exec__(8689)));
module.exports = __webpack_exports__;

})();
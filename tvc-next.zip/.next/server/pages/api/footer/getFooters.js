"use strict";
(() => {
var exports = {};
exports.id = 1454;
exports.ids = [1454];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 4448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_footerController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9925);
/* harmony import */ var _controller_footerController__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_controller_footerController__WEBPACK_IMPORTED_MODULE_0__);

async function handler(req, res) {
    const result = await (0,_controller_footerController__WEBPACK_IMPORTED_MODULE_0__.getFooter)();
    res.json(result);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9925], () => (__webpack_exec__(4448)));
module.exports = __webpack_exports__;

})();
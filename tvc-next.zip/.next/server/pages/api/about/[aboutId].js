"use strict";
(() => {
var exports = {};
exports.id = 9946;
exports.ids = [9946];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 7430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_aboutusController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4654);
/* harmony import */ var _controller_aboutusController__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_controller_aboutusController__WEBPACK_IMPORTED_MODULE_0__);

async function handler(req, res) {
    const aboutId = req.query.aboutId;
    const method = req.method;
    let result;
    switch(method){
        case "GET":
            result = await (0,_controller_aboutusController__WEBPACK_IMPORTED_MODULE_0__.getAboutUsById)(aboutId);
            res.json(result);
            break;
        case "DELETE":
            result = await (0,_controller_aboutusController__WEBPACK_IMPORTED_MODULE_0__.deleteAboutUsById)(aboutId);
            res.json({
                ...result,
                message: `about us with aboutId: ${aboutId} deleted`
            });
            break;
        case "POST":
            const section1 = req.body.section1;
            const section1_vn = req.body.section1_vn;
            const section2 = req.body.section2;
            const section2_vn = req.body.section2_vn;
            result = await (0,_controller_aboutusController__WEBPACK_IMPORTED_MODULE_0__.createAboutUs)(section1, section1_vn, section2, section2_vn);
            res.status(201).json({
                ...result,
                message: `about us created`
            });
            break;
        case "PUT":
            const updateSection1 = req.body.section1;
            const updatedSection1_vn = req.body.section1_vn;
            const updateSection2 = req.body.section2;
            const updatedSection2_vn = req.body.section2_vn;
            result = await (0,_controller_aboutusController__WEBPACK_IMPORTED_MODULE_0__.updateAboutUs)(aboutId, updateSection1, updatedSection1_vn, updateSection2, updatedSection2_vn);
            res.status(204).end("end");
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4654], () => (__webpack_exec__(7430)));
module.exports = __webpack_exports__;

})();
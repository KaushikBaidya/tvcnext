"use strict";
(() => {
var exports = {};
exports.id = 4994;
exports.ids = [4994];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 7202:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_userController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5024);
/* harmony import */ var _controller_userController__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_controller_userController__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__);


const bcrypt = __webpack_require__(7096);
async function handler(req, res) {
    const method = req.method;
    if (method === "POST") {
        let result;
        const user = req.body.username;
        const password = req.body.password;
        result = await (0,_controller_userController__WEBPACK_IMPORTED_MODULE_0__.getUser)(user);
        console.log(result.length);
        if (result.length > 0) {
            const hashedPassword = result[0].password;
            // if (user === "admin" && password === "admin") {
            if (await bcrypt.compare(password, hashedPassword)) {
                var token = jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default().sign({
                    success: true,
                    user,
                    fullname: result[0].fullname,
                    role: "admin"
                }, "jwtSecret", {
                    expiresIn: "2d"
                });
                res.status(200).json({
                    token,
                    fullname: result[0].fullname,
                    message: "Login Success"
                });
            } else {
                return res.json({
                    message: "Login failed"
                });
            }
        } else {
            return res.json({
                message: "User Not Found"
            });
        }
    } else {
        // res.json({ message: "not success login" });
        return res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5024], () => (__webpack_exec__(7202)));
module.exports = __webpack_exports__;

})();
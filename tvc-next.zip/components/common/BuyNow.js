import React, { Fragment, useState } from "react";
// import { AiOutlineRest } from "react-icons/ai";
import { Dialog, Transition } from "@headlessui/react";
import BuyForm from "./BuyForm";
// import toast from "react-hot-toast";

const BuyNow = ({ title }) => {
  let [isOpen, setIsOpen] = useState(false);
  //   const { t } = useTranslation(['product'])

  function closeModal() {
    setIsOpen(false);
  }

  function openModal() {
    setIsOpen(true);
  }

  return (
    <>
      <button
        className=" bg-orange px-10 py-2 rounded-lg text-white font-semibold "
        onClick={() => {
          openModal();
        }}
      >
        {/* {t("button")} */}
        Buy Now
      </button>

      <Transition appear show={isOpen} as={Fragment}>
        <Dialog
          as="div"
          className="fixed inset-0 overflow-y-auto"
          onClose={closeModal}
        >
          <div className="min-h-screen px-4 text-center ">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <Dialog.Overlay className="fixed inset-0 bg-gray-900 bg-opacity-70" />
            </Transition.Child>

            {/* This element is to trick the browser into centering the modal contents. */}
            <span
              className="inline-block h-screen align-middle"
              aria-hidden="true"
            >
              &#8203;
            </span>
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <div className="inline-block w-full max-w-lg overflow-hidden text-left align-middle rounded-2xl my-24 bg-lime-300 p-10 transition-all transform z-40">
                <BuyForm title={title} />
              </div>
              {/* <div className="inline-block w-full max-w-lg p-12 my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl ">
                <BuyForm title={title} />
              </div> */}
            </Transition.Child>
          </div>
        </Dialog>
      </Transition>
    </>
  );
};

export default BuyNow;

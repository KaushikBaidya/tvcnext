const mysqlConfig = {
  // host: "localhost",
  // database: "tvcvlnrr_rocket",
  // user: "tvcvlnrr_cit",
  // password: "m6w,b!jG2s=e",
  //------------
  // host: "localhost",
  // user: "root",
  // database: "tvc",
  // password: "password",
  // port: 3306,
  //-------------
  host: "localhost",
  user: "exhortde_mh",
  password: "em(.xwh@5^y.",
  database: "exhortde_test",
  port: "3306",
};

export default mysqlConfig;

"use strict";
exports.id = 2105;
exports.ids = [2105];
exports.modules = {

/***/ 8145:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ request)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const client = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "/api"
});
const request = async ({ ...options })=>{
    const res = await client(options);
    return res;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2105:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ag": () => (/* binding */ useDeleteData),
/* harmony export */   "KQ": () => (/* binding */ useGetData),
/* harmony export */   "gU": () => (/* binding */ usePutData),
/* harmony export */   "u5": () => (/* binding */ usePostData)
/* harmony export */ });
/* harmony import */ var _helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8145);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1199);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__]);
_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const usePostData = ()=>{
    const value = (0,_context_context__WEBPACK_IMPORTED_MODULE_2__/* .useGlobalContext */ .b)();
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(({ path , formData  })=>(0,_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__/* .request */ .W)({
            method: "POST",
            url: path,
            data: formData,
            headers: {
                Authorization: "Bearer " + value.token
            }
        }));
};
const usePutData = ()=>{
    const value = (0,_context_context__WEBPACK_IMPORTED_MODULE_2__/* .useGlobalContext */ .b)();
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(({ path , formData  })=>(0,_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__/* .request */ .W)({
            method: "PUT",
            url: path,
            data: formData,
            headers: {
                Authorization: "Bearer " + value.token
            }
        }));
};
const useGetData = (key, path)=>{
    const value = (0,_context_context__WEBPACK_IMPORTED_MODULE_2__/* .useGlobalContext */ .b)();
    const { status , data , error , isLoading , isError , refetch  } = (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        key,
        {
            path: path,
            headers: {
                Authorization: "Bearer " + value.token
            }
        }, 
    ], ({ queryKey , signal  })=>{
        const { path , headers  } = queryKey[1];
        return (0,_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__/* .request */ .W)({
            method: "GET",
            url: path,
            headers: headers,
            signal
        });
    });
    return {
        status,
        data,
        error,
        isLoading,
        isError,
        refetch
    };
};
const useDeleteData = ()=>{
    const value = (0,_context_context__WEBPACK_IMPORTED_MODULE_2__/* .useGlobalContext */ .b)();
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(({ path  })=>(0,_helper_axios_utils__WEBPACK_IMPORTED_MODULE_0__/* .request */ .W)({
            method: "DELETE",
            url: path,
            headers: {
                Authorization: "Bearer " + value.token
            }
        }));
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
"use strict";
exports.id = 4654;
exports.ids = [4654];
exports.modules = {

/***/ 6328:
/***/ ((__unused_webpack_module, exports) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
exports.Z = _interopRequireDefault;
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}


/***/ }),

/***/ 4654:
/***/ ((module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
const _interopRequireDefault = (__webpack_require__(6328)/* ["default"] */ .Z);
const _db = /*#__PURE__*/ _interopRequireDefault(__webpack_require__(6457));
const mysql = __webpack_require__(2418);
const getAboutUs = async ()=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute("SELECT * FROM `about` ");
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const getAboutUsById = async (aboutId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows] = await connection.execute(`SELECT * FROM about WHERE aboutId = ${aboutId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const createAboutUs = async (section1, section2)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`INSERT INTO about ( section1, section2 ) VALUES ("${section1}","${section2}");`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const updateAboutUs = async (aboutId, updatedSection1, updatedSection2)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`UPDATE about SET section1 = "${updatedSection1}", section2 = "${updatedSection2}" WHERE aboutId = ${aboutId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const deleteAboutUsById = async (aboutId)=>{
    try {
        const connection = await mysql.createConnection(_db.default);
        const [rows, fields] = await connection.execute(`DELETE FROM about WHERE aboutId = ${aboutId}`);
        return rows;
    } catch (e) {
        console.error(e);
    }
};
const about = {
    getAboutUs,
    getAboutUsById,
    createAboutUs,
    updateAboutUs,
    deleteAboutUsById
};
module.exports = about;


/***/ }),

/***/ 6457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mysqlConfig = {
    // host: "localhost",
    // database: "tvcvlnrr_rocket",
    // user: "tvcvlnrr_cit",
    // password: "m6w,b!jG2s=e",
    //------------
    // host: "localhost",
    // user: "root",
    // database: "tvc",
    // password: "password",
    // port: 3306,
    //-------------
    host: "localhost",
    user: "exhortde_mh",
    password: "em(.xwh@5^y.",
    database: "exhortde_test",
    port: "3306"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mysqlConfig);


/***/ })

};
;
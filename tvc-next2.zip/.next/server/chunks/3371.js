"use strict";
exports.id = 3371;
exports.ids = [3371];
exports.modules = {

/***/ 1693:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ErrorMessage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2059);



const InputFile = ({ name , label , accept ="image/*" , register , errorMessage ="" , action ,  })=>{
    const driveUpload = (e)=>{
        var file = e.target.files[0]; //the file
        if (typeof file === "undefined") return;
        var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
        if (!allowedExtensions.exec(file.name)) return;
        var reader = new FileReader(); //this for convert to Base64
        reader.readAsDataURL(e.target.files[0]); //start conversion...
        reader.onload = function(e) {
            //.. once finished..
            var rawLog = reader.result.split(",")[1]; //extract only thee file data part
            var dataSend = {
                dataReq: {
                    data: rawLog,
                    name: file.name,
                    type: file.type
                },
                fname: "uploadFilesToGoogleDrive"
            }; //preapre info to send to API
            fetch("https://script.google.com/macros/s/AKfycbyPYSAxwvQTnmVmC7r15tz9caXfim2tLuB-GWko-oEzKRSw9ns/exec", {
                method: "POST",
                body: JSON.stringify(dataSend)
            }) //send to Api
            .then((res)=>res.json()).then((a)=>{
                action(a.id);
            }).catch((e)=>console.log(e)); // Or Error in console
        };
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "form-row w-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "file",
                accept: accept,
                className: "border-red-800",
                ...register(name),
                onChange: (e)=>driveUpload(e)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                message: errorMessage
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputFile);


/***/ }),

/***/ 1925:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ErrorMessage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2059);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const QuillNoSSRWrapper = next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\admin\\RichText.js -> " + "react-quill"
        ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            children: "Loading ..."
        })
});
const modules = {
    toolbar: [
        [
            {
                header: "1"
            },
            {
                header: "2"
            },
            {
                font: []
            }
        ],
        [
            {
                size: []
            }
        ],
        [
            "bold",
            "italic",
            "underline",
            "strike",
            "blockquote"
        ],
        [
            {
                list: "ordered"
            },
            {
                list: "bullet"
            },
            {
                indent: "-1"
            },
            {
                indent: "+1"
            }, 
        ],
        [
            "link",
            "image",
            "video"
        ],
        [
            "clean"
        ],
        [
            {
                color: []
            },
            {
                background: []
            }
        ], 
    ],
    clipboard: {
        // toggle to add extra line breaks when pasting HTML:
        matchVisual: false
    }
};
const formats = [
    "header",
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "blockquote",
    "list",
    "bullet",
    "indent",
    "link",
    "image",
    "video",
    "color",
    "background", 
];
const RichText = ({ control , name , label , errorMessage =""  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "form-row w-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
                control: control,
                name: name,
                rules: {
                    required: "Description is required"
                },
                render: ({ field  })=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(QuillNoSSRWrapper, {
                        modules: modules,
                        formats: formats,
                        ...field,
                        theme: "snow"
                    });
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-11",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ErrorMessage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    message: errorMessage
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RichText);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 642:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C1": () => (/* binding */ SelectFromDb)
/* harmony export */ });
/* unused harmony exports SelectFromOptions, DataListFromDb, SelectAllFromDb */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _hooks_DataApi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2105);
/* harmony import */ var _ErrorMessage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2059);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hooks_DataApi__WEBPACK_IMPORTED_MODULE_3__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hooks_DataApi__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const SelectFromDb = ({ control , label , path , name , errorMessage , isDisabled =false ,  })=>{
    const { data: lists  } = (0,_hooks_DataApi__WEBPACK_IMPORTED_MODULE_3__/* .useGetData */ .KQ)(label, path);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "form-row w-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                control: control,
                name: name,
                render: ({ field  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        className: "form-control " + (isDisabled === true ? "bg-gray-100" : "bg-white"),
                        ...field,
                        disabled: isDisabled,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "",
                                children: "-- Select --"
                            }),
                            lists?.data.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                    value: item.listId,
                                    children: item.listName
                                }, item.listId))
                        ]
                    })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ErrorMessage__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                message: errorMessage
            })
        ]
    });
};
const SelectFromOptions = ({ register , options , label , name , errorMessage , ...rest })=>{
    console.log(options);
    return /*#__PURE__*/ _jsxs("div", {
        className: "form-row w-full",
        children: [
            /*#__PURE__*/ _jsx("label", {
                children: label
            }),
            /*#__PURE__*/ _jsxs("select", {
                className: "form-control bg-white",
                ...register(name),
                ...rest,
                children: [
                    /*#__PURE__*/ _jsx("option", {
                        value: "",
                        children: "-- Select --"
                    }),
                    options.map((value)=>/*#__PURE__*/ _jsx("option", {
                            value: value,
                            children: value
                        }, value))
                ]
            }),
            /*#__PURE__*/ _jsx(ErrorMessage, {
                message: errorMessage
            })
        ]
    });
};
const DataListFromDb = ({ register , label , path , name , errorMessage , isDisabled =false , autoFocus =false ,  })=>{
    const { data: lists  } = useGetData(label, path);
    return /*#__PURE__*/ _jsxs("div", {
        className: "form-row w-full",
        children: [
            /*#__PURE__*/ _jsx("label", {
                children: label
            }),
            /*#__PURE__*/ _jsx("input", {
                list: "browsers",
                ...register(name),
                className: "form-control " + (isDisabled === true ? "bg-gray-100" : "bg-white"),
                autoFocus: autoFocus
            }),
            /*#__PURE__*/ _jsx("datalist", {
                id: "browsers",
                children: lists?.data.map((item)=>/*#__PURE__*/ _jsx("option", {
                        value: item.listName
                    }, item.listId))
            }),
            /*#__PURE__*/ _jsx(ErrorMessage, {
                message: errorMessage
            })
        ]
    });
};
const SelectAllFromDb = ({ control , label , path , name , errorMessage , isDisabled =false ,  })=>{
    const { data: lists  } = useGetData(label, path);
    return /*#__PURE__*/ _jsxs("div", {
        className: "form-row w-full",
        children: [
            /*#__PURE__*/ _jsx("label", {
                children: label
            }),
            /*#__PURE__*/ _jsx(Controller, {
                control: control,
                name: name,
                render: ({ field  })=>/*#__PURE__*/ _jsxs("select", {
                        className: "form-control " + (isDisabled === true ? "bg-gray-100" : "bg-white"),
                        ...field,
                        disabled: isDisabled,
                        children: [
                            /*#__PURE__*/ _jsx("option", {
                                value: "All",
                                children: "-- All --"
                            }),
                            lists?.data.map((item)=>/*#__PURE__*/ _jsx("option", {
                                    value: item.listId,
                                    children: item.listName
                                }, item.listId))
                        ]
                    })
            }),
            /*#__PURE__*/ _jsx(ErrorMessage, {
                message: errorMessage
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3371:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1908);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var _Input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3096);
/* harmony import */ var _common_button_SaveButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6139);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _InputFile__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1693);
/* harmony import */ var _admin_SelectList__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(642);
/* harmony import */ var _RichText__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1925);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _admin_SelectList__WEBPACK_IMPORTED_MODULE_11__, _RichText__WEBPACK_IMPORTED_MODULE_12__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _admin_SelectList__WEBPACK_IMPORTED_MODULE_11__, _RichText__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const schema = yup__WEBPACK_IMPORTED_MODULE_2__.object({
    productId: yup__WEBPACK_IMPORTED_MODULE_2__.string().max(50),
    categoryId: yup__WEBPACK_IMPORTED_MODULE_2__.string().required("Required.").max(50),
    name: yup__WEBPACK_IMPORTED_MODULE_2__.string().required("Required.").max(50),
    name_vn: yup__WEBPACK_IMPORTED_MODULE_2__.string().required("Required.").max(50),
    description: yup__WEBPACK_IMPORTED_MODULE_2__.string().required("Required."),
    description_vn: yup__WEBPACK_IMPORTED_MODULE_2__.string().required("Required.")
}).shape({
    filepath: yup__WEBPACK_IMPORTED_MODULE_2__.mixed()
});
const ProductForm = ({ defaultValues , path , mutateAsync , action , btnText , returnPath ,  })=>{
    const { 0: imageUrl , 1: setPhoto  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(defaultValues.image);
    const { 0: submitting , 1: setSubmitting  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const { register , handleSubmit , reset , control , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useForm)({
        defaultValues: defaultValues,
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__.yupResolver)(schema)
    });
    const { name , name_vn , description , description_vn , filepath , categoryId  } = errors;
    const onSubmit = async (formData)=>{
        if (imageUrl === "") {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Upload not complete! Please wait.");
            return;
        }
        setSubmitting(true);
        let data = {
            productId: formData.productId,
            name: formData.name,
            name_vn: formData.name_vn,
            description: formData.description,
            description_vn: formData.description_vn,
            category: formData.categoryId,
            image: imageUrl
        };
        try {
            const { status  } = await mutateAsync({
                path: path,
                formData: data
            });
            if (status === 201) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Saved successfully!");
                reset();
            }
            if (status === 204) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Update successful!");
                router.push(returnPath);
            }
        } catch (error) {
            if (error.response) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Response : " + error.response.data);
            } else if (error.request) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Request : " + error.message);
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Error :", error.message);
            }
        } finally{
            setPhoto("");
            setSubmitting(false);
            action();
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "hidden",
                ...register("productId")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "form-col",
                children: [
                    imageUrl?.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                        src: `https://drive.google.com/thumbnail?id=${imageUrl}`,
                        alt: "PHOTO",
                        width: 200,
                        height: 100
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputFile__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        name: "filepath",
                        label: "Upload Product Image",
                        accept: "image/*",
                        register: register,
                        action: setPhoto,
                        errorMessage: filepath?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        name: "name",
                        label: "Product Name",
                        type: "text",
                        register: register,
                        errorMessage: name?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        name: "name_vn",
                        label: "Product Name Vietnam",
                        type: "text",
                        register: register,
                        errorMessage: name_vn?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_admin_SelectList__WEBPACK_IMPORTED_MODULE_11__/* .SelectFromDb */ .C1, {
                        control: control,
                        label: "Category",
                        path: "/selectCategory",
                        name: "categoryId",
                        errorMessage: categoryId?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RichText__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        control: control,
                        label: "Description",
                        name: "description",
                        errorMessage: description?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RichText__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        control: control,
                        label: "Description Vietnam",
                        name: "description_vn",
                        errorMessage: description_vn?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_button_SaveButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        btnText: btnText,
                        disabled: submitting
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6139:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const SaveButton = ({ btnText , disabled , isRow =true  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: isRow ? "form-row w-full" : "md:mt-6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            type: "submit",
            className: "save-btn",
            disabled: disabled,
            children: btnText
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SaveButton);


/***/ })

};
;
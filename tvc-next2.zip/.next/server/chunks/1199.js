"use strict";
exports.id = 1199;
exports.ids = [1199];
exports.modules = {

/***/ 1199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "w": () => (/* binding */ AppProvider),
  "b": () => (/* binding */ useGlobalContext)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./context/useData.js
// import createPersistedState from "use-persisted-state";
// const useAuthState = createPersistedState("auth");
// const useTokenState = createPersistedState("token");
// import usePersistedState from "use-persisted-state-hook";
// const useAuthState = usePersistedState("auth");
// const useTokenState = usePersistedState("token");

const useData = ()=>{
    const { 0: user , 1: setUser  } = (0,external_react_.useState)(null);
    const { 0: token , 1: setToken  } = (0,external_react_.useState)(null);
    // const [user, setUser] = usePersistedState("");
    // const [token, setToken] = usePersistedState("");
    const signOut = ()=>{
        setUser("");
        setToken();
    };
    return {
        user,
        setUser,
        token,
        setToken,
        signOut
    };
};
/* harmony default export */ const context_useData = (useData);

;// CONCATENATED MODULE: ./context/context.js



const AppContext = /*#__PURE__*/ (0,external_react_.createContext)(null);
const AppProvider = ({ children  })=>{
    const data = context_useData();
    return /*#__PURE__*/ jsx_runtime_.jsx(AppContext.Provider, {
        value: data,
        children: children
    });
};
const useGlobalContext = ()=>{
    return (0,external_react_.useContext)(AppContext);
};



/***/ })

};
;
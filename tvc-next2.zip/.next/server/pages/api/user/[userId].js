"use strict";
(() => {
var exports = {};
exports.id = 6304;
exports.ids = [6304];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 8415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_userController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5024);
/* harmony import */ var _controller_userController__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_controller_userController__WEBPACK_IMPORTED_MODULE_0__);
const bcrypt = __webpack_require__(7096);

async function handler(req, res) {
    const userId = req.query.userId;
    const method = req.method;
    let result;
    switch(method){
        case "GET":
            result = await getUser(user);
            res.json(result);
            break;
        case "DELETE":
            result = await (0,_controller_userController__WEBPACK_IMPORTED_MODULE_0__.deleteUserById)(userId);
            res.json({
                ...result,
                message: `user with userId: ${userId} deleted`
            });
            break;
        case "POST":
            const user1 = req.body.user;
            const fullname = req.body.fullName;
            const hashedPassword = await bcrypt.hash(req.body.password, 10);
            result = await (0,_controller_userController__WEBPACK_IMPORTED_MODULE_0__.createUser)(user1, fullname, hashedPassword);
            res.json({
                ...result,
                message: `user with name: ${user1} created`
            });
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5024], () => (__webpack_exec__(8415)));
module.exports = __webpack_exports__;

})();
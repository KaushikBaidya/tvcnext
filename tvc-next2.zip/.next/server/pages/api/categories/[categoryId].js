"use strict";
(() => {
var exports = {};
exports.id = 3968;
exports.ids = [3968];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 8639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _controller_categoryController__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1691);
/* harmony import */ var _controller_categoryController__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_controller_categoryController__WEBPACK_IMPORTED_MODULE_0__);

async function handler(req, res) {
    const categoryId = req.query.categoryId;
    const method = req.method;
    let result;
    switch(method){
        case "GET":
            result = await (0,_controller_categoryController__WEBPACK_IMPORTED_MODULE_0__.getCategoryById)(categoryId);
            res.json(result);
            break;
        case "DELETE":
            result = await (0,_controller_categoryController__WEBPACK_IMPORTED_MODULE_0__.deleteCategoryId)(categoryId);
            res.json({
                ...result,
                message: `category with categoryId: ${categoryId} deleted`
            });
            break;
        case "POST":
            const category = req.body.category;
            result = await (0,_controller_categoryController__WEBPACK_IMPORTED_MODULE_0__.createCategory)(category);
            res.status(201).json({
                ...result,
                message: `category with title: ${category} created`
            });
            break;
        case "PUT":
            const updatedCategory = req.body.category;
            result = await (0,_controller_categoryController__WEBPACK_IMPORTED_MODULE_0__.updateCategory)(categoryId, updatedCategory);
            res.status(204).end("end");
            break;
        default:
            res.status(405).end(`Method ${method} Not Allowed`);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1691], () => (__webpack_exec__(8639)));
module.exports = __webpack_exports__;

})();